CSCE 438 HW2 Submission
Will Adams and Nicholas Jackson
Section 500

Compile the code using the provided makefile:

    make

To clear the directory (and remove .txt files):

    make clean

To run both master and chat server on lenss-comp1.cse.tamu.edu:

    bin/startMaster.sh

To run chat server on any other machines:

    bin/startSlave.sh

