CSCE 438 HW2 Submission
Will Adams and Nicholas Jackson
Section 500

Compile the code using the provided makefile:

    make

To clear the directory (and remove .txt files):
   
    make clean

To run the server on port 3010 (the default port used for testing):

    ./fbsd -p 3010

To run the client on the localhost, on port 3010, and with username "user1": 

    ./fbc -h localhost -p 3010 -u user1

